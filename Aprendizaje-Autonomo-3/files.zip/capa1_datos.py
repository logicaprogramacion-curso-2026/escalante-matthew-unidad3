"""
Capa 1 - Datos
Responsable únicamente de cargar y validar la información del examen
desde un archivo JSON. No contiene lógica de evaluación.
"""

import json
from pathlib import Path
from typing import Any


TIPOS_VALIDOS = {
    "opcion_unica",
    "opcion_multiple",
    "verdadero_falso",
    "emparejamiento",
    "completar",
}


class ErrorCargaDatos(Exception):
    """Se lanza cuando el archivo de preguntas es inválido o no existe."""


def cargar_examen(ruta_json: str) -> dict[str, Any]:
    """
    Carga un examen desde un archivo JSON y valida su estructura mínima.

    Args:
        ruta_json: ruta al archivo .json con el banco de preguntas.

    Returns:
        Diccionario con las claves 'examen' y 'preguntas'.
    """
    path = Path(ruta_json)
    if not path.exists():
        raise ErrorCargaDatos(f"No se encontró el archivo: {ruta_json}")

    with open(path, encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError as e:
            raise ErrorCargaDatos(f"JSON inválido: {e}") from e

    if "preguntas" not in data or not isinstance(data["preguntas"], list):
        raise ErrorCargaDatos("El JSON debe contener una lista 'preguntas'.")

    for i, pregunta in enumerate(data["preguntas"], start=1):
        _validar_pregunta(pregunta, i)

    return data


def _validar_pregunta(pregunta: dict[str, Any], indice: int) -> None:
    campos_requeridos = {"id", "tipo", "pregunta", "respuesta_correcta", "puntaje"}
    faltantes = campos_requeridos - pregunta.keys()
    if faltantes:
        raise ErrorCargaDatos(
            f"Pregunta #{indice}: faltan campos {faltantes}"
        )
    if pregunta["tipo"] not in TIPOS_VALIDOS:
        raise ErrorCargaDatos(
            f"Pregunta #{indice}: tipo '{pregunta['tipo']}' no soportado. "
            f"Tipos válidos: {TIPOS_VALIDOS}"
        )


def obtener_preguntas(examen: dict[str, Any]) -> list[dict[str, Any]]:
    """Devuelve solo la lista de preguntas de un examen ya cargado."""
    return examen["preguntas"]
