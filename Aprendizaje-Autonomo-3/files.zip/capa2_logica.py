"""
Capa 2 - Lógica
Comparación exacta y normalizada de respuestas, cálculo de puntaje
y generación de retroalimentación. No sabe nada de JSON ni de CLI.
"""

import unicodedata
from typing import Any


def normalizar(texto: str) -> str:
    """
    Normaliza texto para comparación: minúsculas, sin espacios extra
    y sin tildes/acentos.
    """
    if not isinstance(texto, str):
        texto = str(texto)
    texto = texto.strip().lower()
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return texto


def _comparar_opcion_unica(correcta: str, respuesta: str) -> bool:
    return normalizar(correcta) == normalizar(respuesta)


def _comparar_opcion_multiple(correcta: list[str], respuesta: list[str]) -> bool:
    set_correcta = {normalizar(x) for x in correcta}
    set_respuesta = {normalizar(x) for x in respuesta}
    return set_correcta == set_respuesta


def _comparar_verdadero_falso(correcta: str, respuesta: str) -> bool:
    return normalizar(correcta) == normalizar(respuesta)


def _comparar_emparejamiento(correcta: dict[str, str], respuesta: dict[str, str]) -> bool:
    if set(correcta.keys()) != set(respuesta.keys()):
        return False
    return all(
        normalizar(correcta[k]) == normalizar(respuesta.get(k, ""))
        for k in correcta
    )


def _comparar_completar(correcta: str, respuesta: str) -> bool:
    return normalizar(correcta) == normalizar(respuesta)


COMPARADORES = {
    "opcion_unica": _comparar_opcion_unica,
    "opcion_multiple": _comparar_opcion_multiple,
    "verdadero_falso": _comparar_verdadero_falso,
    "emparejamiento": _comparar_emparejamiento,
    "completar": _comparar_completar,
}


def evaluar_respuesta(pregunta: dict[str, Any], respuesta_usuario: Any) -> bool:
    """Determina si la respuesta del usuario es correcta para una pregunta dada."""
    tipo = pregunta["tipo"]
    comparador = COMPARADORES.get(tipo)
    if comparador is None:
        raise ValueError(f"Tipo de pregunta no soportado: {tipo}")
    return comparador(pregunta["respuesta_correcta"], respuesta_usuario)


def evaluar_examen(
    preguntas: list[dict[str, Any]], respuestas_usuario: dict[int, Any]
) -> dict[str, Any]:
    """
    Evalúa un examen completo.

    Args:
        preguntas: lista de preguntas (Capa 1).
        respuestas_usuario: dict {id_pregunta: respuesta_dada}.

    Returns:
        Resumen con puntaje total, máximo posible y detalle por pregunta.
    """
    detalle = []
    puntaje_total = 0
    puntaje_maximo = 0

    for pregunta in preguntas:
        pid = pregunta["id"]
        puntaje_maximo += pregunta["puntaje"]
        respuesta_usuario = respuestas_usuario.get(pid)

        if respuesta_usuario is None:
            correcta = False
        else:
            correcta = evaluar_respuesta(pregunta, respuesta_usuario)

        puntos_obtenidos = pregunta["puntaje"] if correcta else 0
        puntaje_total += puntos_obtenidos

        detalle.append({
            "id": pid,
            "pregunta": pregunta["pregunta"],
            "correcta": correcta,
            "puntaje_obtenido": puntos_obtenidos,
            "puntaje_posible": pregunta["puntaje"],
            "respuesta_dada": respuesta_usuario,
            "respuesta_correcta": pregunta["respuesta_correcta"],
            "retroalimentacion": None if correcta else pregunta.get(
                "retroalimentacion_error", "Respuesta incorrecta."
            ),
        })

    return {
        "puntaje_total": puntaje_total,
        "puntaje_maximo": puntaje_maximo,
        "porcentaje": round(100 * puntaje_total / puntaje_maximo, 1) if puntaje_maximo else 0,
        "detalle": detalle,
    }
