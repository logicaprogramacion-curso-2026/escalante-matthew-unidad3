"""
Prototipo semana 4: demuestra la integración de Capa 1 (datos) y
Capa 2 (lógica) usando respuestas de usuario simuladas (mock).
Aún no incluye Capa 3 (CLI) ni integración con LLM.
"""

from capa1_datos import cargar_examen, obtener_preguntas
from capa2_logica import evaluar_examen

# Respuestas "mock" que simulan lo que un estudiante respondería.
# Intencionalmente incluyen aciertos y errores de distintos tipos.
RESPUESTAS_MOCK = {
    1: "alu",                              # correcta (normalización de mayúsculas)
    2: ["RAM", "Caché", "ALU"],            # incorrecta (incluye ALU de más)
    3: "Verdadero",                        # correcta
    4: {                                   # correcta
        "CPU": "Procesa instrucciones",
        "RAM": "Almacenamiento temporal",
        "Disco duro": "Almacenamiento permanente",
    },
    5: "Planificación de Procesos",        # correcta (normalización de tildes/mayúsculas)
}


def main() -> None:
    examen = cargar_examen("data/preguntas.json")
    preguntas = obtener_preguntas(examen)

    resultado = evaluar_examen(preguntas, RESPUESTAS_MOCK)

    print(f"Examen: {examen['examen']}\n")
    for item in resultado["detalle"]:
        estado = "✅ Correcta" if item["correcta"] else "❌ Incorrecta"
        print(f"[{item['id']}] {item['pregunta']}")
        print(f"    {estado} | {item['puntaje_obtenido']}/{item['puntaje_posible']} pts")
        if item["retroalimentacion"]:
            print(f"    Retroalimentación: {item['retroalimentacion']}")
        print()

    print(f"Puntaje total: {resultado['puntaje_total']}/{resultado['puntaje_maximo']} "
          f"({resultado['porcentaje']}%)")


if __name__ == "__main__":
    main()
